import React from 'react'

const Loader = () => {
  return (
    <div className='bg-black h-screen'>Loader</div>
  )
}

export default Loader